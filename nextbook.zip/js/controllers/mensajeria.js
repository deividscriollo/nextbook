var app=angular.module('app').controller('mensajeCtrl', function ($scope) {
	console.log('test');
});